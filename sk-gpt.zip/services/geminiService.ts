
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";

export class GeminiService {
  private static getAI() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  static async checkKeySelection(): Promise<boolean> {
    if ((window as any).aistudio?.hasSelectedApiKey) {
      return await (window as any).aistudio.hasSelectedApiKey();
    }
    return true;
  }

  static async openKeySelector() {
    if ((window as any).aistudio?.openSelectKey) {
      await (window as any).aistudio.openSelectKey();
    }
  }

  /**
   * Categorizes errors to identify if they are related to API Key, billing, permissions, or missing resources.
   */
  static isKeyError(error: any): boolean {
    const msg = error?.message || String(error);
    const lowercaseMsg = msg.toLowerCase();
    
    // 404 "Requested entity was not found" usually indicates the project/key 
    // doesn't have access to the specific model (e.g. Imagen 3 or Veo).
    return (
      lowercaseMsg.includes('requested entity was not found') ||
      lowercaseMsg.includes('not_found') ||
      lowercaseMsg.includes('404') ||
      lowercaseMsg.includes('403') ||
      lowercaseMsg.includes('401') ||
      lowercaseMsg.includes('permission_denied') ||
      lowercaseMsg.includes('api_key_invalid') ||
      lowercaseMsg.includes('api key not found')
    );
  }

  static async *chatStream(
    message: string, 
    history: any[] = [], 
    options: { 
      useSearch?: boolean; 
      useThinking?: boolean;
      useTurbo?: boolean;
      attachment?: { data: string; mimeType: string };
    } = {}
  ) {
    const ai = this.getAI();
    const { useSearch, useThinking, useTurbo, attachment } = options;

    // Use guidelines for model selection
    let model = 'gemini-3-flash-preview'; 
    if (useTurbo) model = 'gemini-2.5-flash-lite-latest';
    if (useThinking) model = 'gemini-3-pro-preview';

    const parts: any[] = [{ text: message }];
    if (attachment) {
      parts.push({
        inlineData: {
          data: attachment.data.split(',')[1],
          mimeType: attachment.mimeType
        }
      });
    }

    const recentHistory = history.slice(-10).map(h => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: h.parts
    }));

    const config: any = {
      systemInstruction: "You are SK GPT, a lightning-fast omniscient AI. Give concise, high-impact answers. Access world knowledge instantly.",
      temperature: 0.7,
      topP: 0.8,
      topK: 40,
    };

    if (useThinking) {
      config.thinkingConfig = { thinkingBudget: 16000 };
    }

    if (useSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    const result = await ai.models.generateContentStream({
      model,
      contents: [...recentHistory, { role: 'user', parts }],
      config
    });

    for await (const chunk of result) {
      yield chunk;
    }
  }

  static async chat(
    message: string, 
    history: any[] = [], 
    options: { 
      useSearch?: boolean; 
      useMaps?: boolean; 
      useThinking?: boolean;
      useTurbo?: boolean;
      attachment?: { data: string; mimeType: string };
    } = {}
  ) {
    const ai = this.getAI();
    const { useSearch, useMaps, useThinking, useTurbo, attachment } = options;

    let model = 'gemini-3-flash-preview'; 
    if (useTurbo) model = 'gemini-2.5-flash-lite-latest';
    if (useThinking) model = 'gemini-3-pro-preview';
    if (useMaps) model = 'gemini-2.5-flash-lite-latest'; // 2.5 series required for maps

    const parts: any[] = [{ text: message }];
    if (attachment) {
      parts.push({
        inlineData: {
          data: attachment.data.split(',')[1],
          mimeType: attachment.mimeType
        }
      });
    }

    const recentHistory = history.slice(-12).map(h => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: h.parts
    }));

    const config: any = {
      systemInstruction: "You are SK GPT, an omniscient AI entity. Your responses are rapid and insightful. Use markdown.",
    };

    if (useThinking) {
      config.thinkingConfig = { thinkingBudget: 24576 };
    }

    if (useSearch || useMaps) {
      config.tools = [];
      if (useSearch) config.tools.push({ googleSearch: {} });
      if (useMaps) config.tools.push({ googleMaps: {} });
    }

    const response = await ai.models.generateContent({
      model,
      contents: [...recentHistory, { role: 'user', parts }],
      config
    });

    const groundingLinks = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => {
      if (chunk.web) return { title: chunk.web.title, uri: chunk.web.uri };
      if (chunk.maps) return { title: chunk.maps.title, uri: chunk.maps.uri };
      return null;
    }).filter(Boolean) || [];

    return {
      text: response.text || "Synchronicity lost.",
      groundingLinks
    };
  }

  static async generateSpeech(text: string) {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
        },
      },
    });

    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
  }

  static decodeBase64(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  static encodeBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  static async decodeAudioData(
    data: Uint8Array, 
    ctx: AudioContext, 
    sampleRate: number = 24000, 
    numChannels: number = 1
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  static async generateImagePro(prompt: string, options: { size: string; ratio: string }) {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          imageSize: options.size,
          aspectRatio: options.ratio as any
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("Vision sync failed.");
  }

  static async editImage(prompt: string, imageBase64: string) {
    const ai = this.getAI();
    const cleanBase64 = imageBase64.split(',')[1];
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: cleanBase64, mimeType: 'image/png' } },
          { text: prompt }
        ]
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("Image re-synthesis failed.");
  }

  static async startVideoGeneration(prompt: string, options: { ratio: string; imageBase64?: string }) {
    const ai = this.getAI();
    const payload: any = {
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt || 'Cinematic data stream',
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: options.ratio
      }
    };

    if (options.imageBase64) {
      payload.image = {
        imageBytes: options.imageBase64.split(',')[1],
        mimeType: 'image/png'
      };
    }

    return await ai.models.generateVideos(payload);
  }

  static async pollVideoOperation(operation: any) {
    const ai = this.getAI();
    return await ai.operations.getVideosOperation({ operation });
  }

  static async fetchVideoBlob(uri: string) {
    const response = await fetch(`${uri}&key=${process.env.API_KEY}`);
    if (!response.ok) {
      if (response.status === 404) throw new Error("Video resource not found. It may have expired or was restricted.");
      throw new Error(`Neural fetch failed with status ${response.status}`);
    }
    return await response.blob();
  }
}
