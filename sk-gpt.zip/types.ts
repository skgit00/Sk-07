
export enum AppView {
  CHAT = 'CHAT',
  LIVE = 'LIVE',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  groundingLinks?: Array<{ title: string; uri: string }>;
  attachment?: {
    type: 'image' | 'video';
    url: string;
    mimeType: string;
  };
}

export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9';
export type VideoAspectRatio = '16:9' | '9:16';

export interface ImageGeneration {
  id: string;
  prompt: string;
  url: string;
  timestamp: number;
  size?: ImageSize;
  ratio?: AspectRatio;
}

export interface VideoGeneration {
  id: string;
  prompt: string;
  url: string;
  status: 'processing' | 'completed' | 'failed';
  timestamp: number;
  ratio: VideoAspectRatio;
}
