
import React, { useState, useRef, useEffect } from 'react';
import { Message } from './types';
import { GeminiService } from './services/geminiService';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "SK GPT online. Global data synchronization complete. How can I assist you with the world's knowledge today?",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSpeech = async (text: string, id: string) => {
    if (isSpeakingId === id) return;
    setIsSpeakingId(id);
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const ctx = audioContextRef.current;
      const base64Audio = await GeminiService.generateSpeech(text);
      const audioBytes = GeminiService.decodeBase64(base64Audio);
      // decodeAudioData now supports optional sampleRate and numChannels
      const audioBuffer = await GeminiService.decodeAudioData(audioBytes, ctx);
      
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setIsSpeakingId(null);
      source.start();
    } catch (error) {
      console.error("Speech synthesis failed:", error);
      setIsSpeakingId(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));
      
      // Fixed: Property 'chatWithSearch' does not exist, use 'chat' with options
      const response = await GeminiService.chat(input, history, { useSearch: true });
      
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        timestamp: Date.now(),
        groundingLinks: response.groundingLinks
      };
      
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error(error);
      const errorMsg: Message = {
        id: 'error',
        role: 'assistant',
        content: "Neural link timeout. The knowledge grid is unstable. Please retry transmission.",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto px-4 lg:px-8 py-6">
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pb-32 scroll-smooth pr-2">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`
              max-w-[85%] lg:max-w-[75%] rounded-2xl p-4 lg:p-6 relative group
              ${msg.role === 'user' 
                ? 'bg-green-500 text-black font-medium shadow-[0_0_15px_rgba(34,197,94,0.3)]' 
                : 'glass-card border-green-500/20 text-gray-200'}
            `}>
              <div className="text-sm lg:text-base whitespace-pre-wrap leading-relaxed mb-2">
                {msg.content}
              </div>
              
              {msg.role === 'assistant' && (
                <button 
                  onClick={() => handleSpeech(msg.content, msg.id)}
                  className={`
                    absolute top-4 right-4 text-green-500/50 hover:text-green-400 transition-colors
                    ${isSpeakingId === msg.id ? 'text-green-400 animate-pulse' : ''}
                  `}
                  title="Vocalize response"
                >
                  <i className={`fa-solid ${isSpeakingId === msg.id ? 'fa-volume-high' : 'fa-volume-low'} text-sm`}></i>
                </button>
              )}
              
              {msg.groundingLinks && msg.groundingLinks.length > 0 && (
                <div className="mt-4 pt-4 border-t border-green-500/10">
                  <span className="text-[10px] uppercase font-bold text-green-500/60 mb-2 block">Knowledge Nodes</span>
                  <div className="flex flex-wrap gap-2">
                    {msg.groundingLinks.map((link, idx) => (
                      <a 
                        key={idx} 
                        href={link.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[11px] bg-green-500/10 hover:bg-green-500/20 text-green-400 px-3 py-1 rounded-full border border-green-500/30 transition-all hover:scale-105"
                      >
                        <i className="fa-solid fa-earth-americas mr-1"></i> {link.title}
                      </a>
                    ))}
                  </div>
                </div>
              )}
              
              <div className={`text-[9px] mt-2 opacity-40 uppercase font-orbitron ${msg.role === 'user' ? 'text-black/70' : 'text-green-500'}`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="glass-card border-green-500/20 p-6 rounded-2xl flex items-center gap-4">
              <div className="relative w-4 h-4">
                <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-20"></div>
                <div className="absolute inset-0 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <span className="text-[10px] uppercase font-orbitron tracking-[0.2em] text-green-500">Retrieving World Intelligence...</span>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-6 left-0 right-0 px-4 max-w-5xl mx-auto">
        <form onSubmit={handleSubmit} className="relative group">
          <div className="absolute -inset-1 bg-green-500 rounded-2xl opacity-10 group-focus-within:opacity-20 transition-opacity blur-lg"></div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Command the grid: Ask anything..."
            className="w-full bg-black/60 border border-green-500/30 rounded-2xl py-5 px-6 pr-32 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition-all glass-card placeholder:text-gray-700 text-lg"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-3 top-2.5 bottom-2.5 px-8 rounded-xl neon-bg text-black font-black uppercase text-xs tracking-widest hover:brightness-110 active:scale-95 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-[0_0_20px_rgba(34,197,94,0.4)]"
          >
            EXECUTE
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
