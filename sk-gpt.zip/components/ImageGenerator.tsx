
import React, { useState, useRef, useEffect } from 'react';
import { GeminiService } from '../services/geminiService';
import { ImageGeneration, ImageSize, AspectRatio } from '../types';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generations, setGenerations] = useState<ImageGeneration[]>([]);
  const [size, setSize] = useState<ImageSize>('1K');
  const [ratio, setRatio] = useState<AspectRatio>('1:1');
  const [editImage, setEditImage] = useState<string | null>(null);
  const [isKeyValid, setIsKeyValid] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkKey = async () => {
      const hasKey = await GeminiService.checkKeySelection();
      setIsKeyValid(hasKey);
    };
    checkKey();
  }, []);

  const handleOpenKeySelection = async () => {
    await GeminiService.openKeySelector();
    // After opening the selector, assume the user might have fixed the issue
    setIsKeyValid(true); 
    setErrorMessage(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setEditImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setErrorMessage(null);
    try {
      let url;
      if (editImage) {
        url = await GeminiService.editImage(prompt, editImage);
      } else {
        url = await GeminiService.generateImagePro(prompt, { size, ratio });
      }
      setGenerations(prev => [{ id: Date.now().toString(), prompt, url, timestamp: Date.now(), size, ratio }, ...prev]);
      setPrompt('');
      setEditImage(null);
    } catch (e: any) {
      console.error("Vision Synthesis Error:", e);
      if (GeminiService.isKeyError(e)) {
        setIsKeyValid(false);
        setErrorMessage("NEURAL KEY INVALID: Vision access requires a billing-enabled project key.");
      } else {
        setErrorMessage(e.message || "VISION CORE OFFLINE: Internal synthesis failure.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isKeyValid) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <div className="glass-card p-12 rounded-[2.5rem] border-red-500/30 text-center flex flex-col items-center max-w-2xl animate-in fade-in zoom-in shadow-[0_0_50px_rgba(239,68,68,0.1)]">
          <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 text-3xl mb-8 border border-red-500/20 shadow-[0_0_30px_rgba(239,68,68,0.2)] animate-pulse">
            <i className="fa-solid fa-triangle-exclamation"></i>
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-red-500 mb-4 tracking-tight uppercase">Vision Access Denied</h3>
          <p className="text-gray-400 mb-8 leading-relaxed">
            High-fidelity Imagen 3 rendering (1K, 2K, 4K) requires an <span className="text-red-500 font-bold">Authenticated Paid Neural Key</span>. Your current link is restricted or billing is inactive.
          </p>
          <div className="flex flex-col gap-4 w-full">
            <button 
              onClick={handleOpenKeySelection}
              className="w-full py-5 bg-red-500 text-white font-black rounded-2xl hover:scale-105 transition-all shadow-[0_0_40px_rgba(239,68,68,0.3)] active:scale-95 text-xs uppercase tracking-widest"
            >
              Re-Authorize Neural Link
            </button>
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-green-400 text-[10px] font-bold uppercase tracking-widest transition-colors"
            >
              Billing Protocol Documentation <i className="fa-solid fa-up-right-from-square ml-1 text-[8px]"></i>
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto flex flex-col h-full">
      <div className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-orbitron font-black text-green-400 mb-2">VISION CORE</h2>
          <p className="text-gray-400 text-sm">Neural patterns synchronized. Ready for high-fidelity synthesis.</p>
        </div>
        <button 
          onClick={handleOpenKeySelection}
          className="text-[10px] font-orbitron font-bold text-green-500/60 hover:text-green-400 transition-colors flex items-center gap-2"
        >
          <i className="fa-solid fa-key"></i> UPDATE KEY
        </button>
      </div>

      <div className="glass-card p-6 rounded-2xl mb-8 border-green-500/20 shadow-xl relative overflow-hidden">
        {isGenerating && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm z-20 flex flex-col items-center justify-center">
            <div className="w-16 h-16 border-4 border-green-500/20 border-t-green-500 rounded-full animate-spin mb-4"></div>
            <p className="font-orbitron text-xs text-green-500 animate-pulse tracking-widest">SYNTHESIZING PIXELS...</p>
          </div>
        )}

        <div className="flex flex-wrap gap-4 mb-6">
          <div className="space-y-2">
            <label className="text-[10px] font-orbitron text-green-500/60 uppercase tracking-widest font-bold">Resolution</label>
            <div className="flex gap-2">
              {['1K', '2K', '4K'].map(s => (
                <button key={s} onClick={() => setSize(s as ImageSize)} className={`px-4 py-1.5 rounded-lg text-[10px] font-bold border transition-all ${size === s ? 'bg-green-500 text-black border-green-500 shadow-[0_0_10px_#22c55e44]' : 'bg-black/40 text-green-500/60 border-green-500/20 hover:bg-green-500/10'}`}>{s}</button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-orbitron text-green-500/60 uppercase tracking-widest font-bold">Aspect Ratio</label>
            <select value={ratio} onChange={(e) => setRatio(e.target.value as AspectRatio)} className="bg-black/40 border border-green-500/20 rounded-lg px-3 py-1.5 text-[10px] font-bold text-green-500 focus:outline-none focus:border-green-500">
              {['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'].map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="ml-auto flex items-end">
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            <button onClick={() => fileInputRef.current?.click()} className={`px-6 py-2 rounded-xl text-[10px] font-orbitron font-bold border transition-all ${editImage ? 'bg-green-500 text-black border-green-500' : 'bg-black/40 text-green-500 border-green-500/30 hover:bg-green-500/10'}`}>
              <i className="fa-solid fa-image-circle-plus mr-2"></i> {editImage ? 'PATTERN LOADED' : 'UPLOAD SOURCE'}
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-[11px] font-bold uppercase tracking-wider text-center animate-in slide-in-from-top-2">
            <i className="fa-solid fa-circle-exclamation mr-2"></i> {errorMessage}
          </div>
        )}

        {editImage && (
          <div className="mb-4 relative w-32 h-32 rounded-xl overflow-hidden border-2 border-green-500/40 group">
            <img src={editImage} className="w-full h-full object-cover" />
            <button onClick={() => setEditImage(null)} className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-red-400 transition-opacity"><i className="fa-solid fa-trash"></i></button>
          </div>
        )}

        <textarea 
          value={prompt} 
          onChange={(e) => setPrompt(e.target.value)} 
          placeholder={editImage ? "Manipulate the loaded pattern..." : "Define the vision protocol..."} 
          className="w-full bg-black/40 border border-green-500/20 rounded-xl p-4 min-h-[120px] focus:outline-none focus:border-green-500 text-lg mb-4 resize-none transition-colors" 
        />
        <div className="flex justify-end">
          <button 
            onClick={handleGenerate} 
            disabled={!prompt.trim() || isGenerating} 
            className="px-10 py-4 neon-bg text-black font-black rounded-xl flex items-center gap-3 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-30 shadow-[0_0_20px_#22c55e44]"
          >
            {isGenerating ? <><i className="fa-solid fa-atom fa-spin"></i> SYNTHESIZING...</> : <><i className="fa-solid fa-wand-magic-sparkles"></i> {editImage ? 'EXECUTE MANIPULATION' : 'INITIATE RENDER'}</>}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {generations.map((gen) => (
            <div key={gen.id} className="group glass-card border-green-500/10 rounded-2xl overflow-hidden hover:border-green-500/40 transition-all shadow-xl">
              <div className="aspect-square relative overflow-hidden bg-black/50">
                <img src={gen.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <a href={gen.url} download={`SK-GPT-${gen.id}.png`} className="w-12 h-12 rounded-full neon-bg text-black flex items-center justify-center hover:scale-110 transition-transform"><i className="fa-solid fa-download"></i></a>
                </div>
              </div>
              <div className="p-4">
                <p className="text-xs text-gray-400 line-clamp-2 italic mb-2">"{gen.prompt}"</p>
                <div className="flex justify-between text-[8px] text-green-500/60 font-orbitron uppercase font-bold">
                  <span>{gen.size} | {gen.ratio}</span>
                  <span>{new Date(gen.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;
