
import React, { useState, useEffect } from 'react';
import { AppView } from '../types';
import { GeminiService } from '../services/geminiService';

interface SidebarProps {
  activeView: AppView;
  onViewChange: (view: AppView) => void;
  isOpen: boolean;
  toggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange, isOpen, toggle }) => {
  const [keyStatus, setKeyStatus] = useState<boolean>(false);
  const [shareStatus, setShareStatus] = useState<string>('SHARE NEURAL LINK');

  useEffect(() => {
    const checkKey = async () => {
      const status = await GeminiService.checkKeySelection();
      setKeyStatus(status);
    };
    checkKey();
    const interval = setInterval(checkKey, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'SK GPT | Neon Intelligence',
          text: 'Access the global knowledge grid with SK GPT.',
          url: url,
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        setShareStatus('LINK COPIED!');
        setTimeout(() => setShareStatus('SHARE NEURAL LINK'), 2000);
      } catch (err) {
        setShareStatus('COPY FAILED');
      }
    }
  };

  const navItems = [
    { id: AppView.CHAT, label: 'Intelligence', icon: 'fa-brain' },
    { id: AppView.LIVE, label: 'Neural Link', icon: 'fa-satellite-dish' },
    { id: AppView.IMAGE, label: 'Vision', icon: 'fa-image' },
    { id: AppView.VIDEO, label: 'Motion', icon: 'fa-clapperboard' },
  ];

  return (
    <>
      {isOpen && <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={toggle} />}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-72 glass-card border-r border-green-500/20 transition-transform duration-300 ease-in-out flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-8 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl neon-bg flex items-center justify-center text-black shadow-[0_0_20px_#22c55e66] animate-pulse">
            <i className="fa-solid fa-bolt-lightning text-2xl"></i>
          </div>
          <div className="flex flex-col">
            <span className="font-orbitron font-black text-2xl neon-text tracking-tighter">SK GPT</span>
            <span className="text-[10px] uppercase tracking-widest text-green-500/60 font-bold font-orbitron">Neural OS v3.3</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <button 
              key={item.id} 
              onClick={() => { onViewChange(item.id); if (window.innerWidth < 1024) toggle(); }} 
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl transition-all duration-300 group ${activeView === item.id ? 'bg-green-500/10 text-green-400 border border-green-500/30 shadow-[inset_0_0_20px_rgba(34,197,94,0.1)]' : 'text-gray-500 hover:text-green-300 hover:bg-white/5'}`}
            >
              <i className={`fa-solid ${item.icon} text-xl w-6 group-hover:scale-110 transition-transform`}></i>
              <span className="font-bold tracking-tight uppercase text-xs font-orbitron">{item.label}</span>
              {activeView === item.id && <div className="ml-auto w-2 h-2 rounded-full neon-bg shadow-[0_0_12px_#22c55e]"></div>}
            </button>
          ))}
        </nav>

        <div className="p-6 space-y-4">
          <button 
            onClick={handleShare}
            className="w-full py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-[10px] font-orbitron font-black text-gray-400 hover:text-white uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3"
          >
            <i className="fa-solid fa-share-nodes"></i> {shareStatus}
          </button>

          <button 
            onClick={async () => {
              await GeminiService.openKeySelector();
              const status = await GeminiService.checkKeySelection();
              setKeyStatus(status);
            }} 
            className="w-full py-4 bg-green-500/5 hover:bg-green-500/20 border border-green-500/20 rounded-2xl text-[10px] font-orbitron font-black text-green-400 uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3"
          >
            <i className="fa-solid fa-key"></i> MANAGE NEURAL KEY
          </button>
          
          <div className="p-5 rounded-2xl bg-black/40 border border-green-500/10 backdrop-blur-md">
            <h3 className="text-[10px] font-orbitron font-black text-green-500/40 mb-3 uppercase tracking-widest">Neural Status</h3>
            <div className="flex items-center gap-3 text-xs font-bold">
              <span className={`flex h-3 w-3 rounded-full ${keyStatus ? 'bg-green-500 animate-pulse shadow-[0_0_8px_#22c55e]' : 'bg-red-500 shadow-[0_0_8px_#ef4444]'}`}></span>
              <span className={keyStatus ? 'text-green-400' : 'text-red-400'}>
                {keyStatus ? 'CORE SYNCHRONIZED' : 'LINK RESTRICTED'}
              </span>
            </div>
            {!keyStatus && (
              <p className="text-[9px] text-gray-500 mt-2 italic leading-tight uppercase font-orbitron">
                Missing Project Entity. Link a billing-enabled key for advanced multimodal access.
              </p>
            )}
            {keyStatus && (
              <p className="text-[8px] text-green-500/40 mt-2 uppercase font-orbitron tracking-tighter">
                Scanning world data via Search & Maps grounding.
              </p>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
