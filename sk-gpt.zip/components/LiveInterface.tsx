
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { GeminiService } from '../services/geminiService';

const LiveInterface: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [modelTranscription, setModelTranscription] = useState('');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const frameIntervalRef = useRef<number | null>(null);

  const startSession = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;

      // Always initialize new GoogleGenAI right before connection as per guidelines.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            // Stream audio from the microphone to the model.
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              
              // Use manual encoding to prevent potential stack issues with spread operator on large buffers.
              const base64 = GeminiService.encodeBase64(new Uint8Array(int16.buffer));
              
              // Use sessionPromise to ensure data is sent only after the session resolves.
              sessionPromise.then(session => {
                session.sendRealtimeInput({ 
                  media: { 
                    data: base64, 
                    mimeType: 'audio/pcm;rate=16000' 
                  } 
                });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);

            // Synchronize video by streaming image frames at a set interval.
            frameIntervalRef.current = window.setInterval(() => {
              if (videoRef.current && canvasRef.current) {
                const ctx = canvasRef.current.getContext('2d');
                if (ctx) {
                  canvasRef.current.width = videoRef.current.videoWidth;
                  canvasRef.current.height = videoRef.current.videoHeight;
                  ctx.drawImage(videoRef.current, 0, 0);
                  canvasRef.current.toBlob(async (blob) => {
                    if (blob) {
                      const arrayBuffer = await blob.arrayBuffer();
                      const base64 = GeminiService.encodeBase64(new Uint8Array(arrayBuffer));
                      sessionPromise.then(session => {
                        session.sendRealtimeInput({ 
                          media: { 
                            data: base64, 
                            mimeType: 'image/jpeg' 
                          } 
                        });
                      });
                    }
                  }, 'image/jpeg', 0.5);
                }
              }
            }, 1000);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Process audio transcriptions.
            if (message.serverContent?.inputTranscription) {
              setTranscription(prev => prev + message.serverContent!.inputTranscription!.text);
            }
            if (message.serverContent?.outputTranscription) {
              setModelTranscription(prev => prev + message.serverContent!.outputTranscription!.text);
            }
            if (message.serverContent?.turnComplete) {
              setTranscription('');
              setModelTranscription('');
            }

            // Process the model's output audio bytes.
            const audioBase64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioBase64 && audioContextRef.current) {
              const ctx = audioContextRef.current;
              // Decode PCM audio data using manual helper.
              const audioBytes = GeminiService.decodeBase64(audioBase64);
              const audioBuffer = await GeminiService.decodeAudioData(audioBytes, ctx, 24000, 1);

              // Schedule each new chunk to ensure smooth playback using nextStartTime cursor.
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            // Clear current playback if interrupted.
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => {
                try { s.stop(); } catch(e) {}
                sourcesRef.current.delete(s);
              });
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => stopSession(),
          onerror: (e) => console.error("Neural Link error:", e)
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: "You are SK GPT in Neural Link mode. You are speaking in real-time. You can see the user through their camera and hear them. Be helpful, concise, and futuristic."
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Failed to establish Neural Link:", err);
    }
  };

  const stopSession = () => {
    setIsActive(false);
    if (sessionRef.current) sessionRef.current.close();
    if (frameIntervalRef.current) {
      window.clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-500/5 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
      </div>

      <div className="z-10 w-full max-w-4xl space-y-8 flex flex-col items-center">
        <div className="text-center space-y-2">
          <h2 className="text-4xl font-orbitron font-black text-green-400 tracking-tighter">NEURAL LINK</h2>
          <p className="text-green-500/60 font-medium uppercase tracking-[0.3em] text-[10px]">Bi-directional Real-time Multimodal Protocol</p>
        </div>

        <div className="relative group w-full max-w-2xl aspect-video rounded-3xl overflow-hidden glass-card border-green-500/20 shadow-2xl">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className={`w-full h-full object-cover transition-all duration-1000 ${isActive ? 'opacity-100 scale-100' : 'opacity-20 scale-110 grayscale blur-sm'}`}
          />
          <canvas ref={canvasRef} className="hidden" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            {!isActive && (
              <div className="text-center animate-in fade-in zoom-in duration-500">
                <div className="w-20 h-20 rounded-full border-2 border-dashed border-green-500/40 flex items-center justify-center mb-4 mx-auto animate-[spin_10s_linear_infinite]">
                  <i className="fa-solid fa-satellite-dish text-2xl text-green-500"></i>
                </div>
                <p className="font-orbitron text-xs text-green-500/40 uppercase tracking-widest">Protocol Offline</p>
              </div>
            )}
            
            {isActive && (
              <div className="absolute top-6 left-6 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_#ef4444]"></span>
                <span className="text-[10px] font-orbitron font-bold text-white uppercase tracking-widest bg-black/40 px-2 py-1 rounded backdrop-blur-md">Live Stream Active</span>
              </div>
            )}
          </div>

          {/* Transcription Overlays */}
          {isActive && (
            <div className="absolute bottom-0 inset-x-0 p-8 space-y-4 bg-gradient-to-t from-black/80 to-transparent">
              {transcription && (
                <div className="flex justify-end">
                  <p className="bg-green-500/10 text-green-300 border border-green-500/20 px-4 py-2 rounded-2xl text-xs backdrop-blur-xl animate-in slide-in-from-right-4">
                    {transcription}
                  </p>
                </div>
              )}
              {modelTranscription && (
                <div className="flex justify-start">
                  <p className="bg-white/10 text-white border border-white/20 px-4 py-2 rounded-2xl text-sm backdrop-blur-xl animate-in slide-in-from-left-4">
                    <span className="text-green-400 font-bold mr-2">SK:</span>
                    {modelTranscription}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-6">
          <button
            onClick={isActive ? stopSession : startSession}
            className={`
              w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl relative
              ${isActive 
                ? 'bg-red-500 text-white hover:rotate-90 hover:scale-95 shadow-red-500/20' 
                : 'neon-bg text-black hover:scale-110 shadow-green-500/40'}
            `}
          >
            {isActive && <div className="absolute inset-0 rounded-full border border-red-500 animate-ping opacity-20"></div>}
            <i className={`fa-solid ${isActive ? 'fa-xmark text-3xl' : 'fa-microphone text-3xl'}`}></i>
          </button>
          
          <p className="text-[10px] font-orbitron font-bold text-green-500/40 uppercase tracking-[0.2em]">
            {isActive ? 'Click to Terminate Link' : 'Initialize Neural Connection'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LiveInterface;
