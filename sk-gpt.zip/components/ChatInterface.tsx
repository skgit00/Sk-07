
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message } from '../types';
import { GeminiService } from '../services/geminiService';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "SK GPT active. Neural-speed communication initialized. Accessing world data...",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(true);
  const [useThinking, setUseThinking] = useState(false);
  const [useTurbo, setUseTurbo] = useState(true); 
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [attachment, setAttachment] = useState<{ url: string; data: string; mimeType: string } | null>(null);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          url: URL.createObjectURL(file),
          data: reader.result as string,
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSpeech = useCallback(async (text: string, id: string) => {
    if (isSpeakingId === id) {
      activeSourceRef.current?.stop();
      setIsSpeakingId(null);
      return;
    }
    
    const cleanText = text.replace(/[*_#`~]/g, '').slice(0, 1000);
    
    activeSourceRef.current?.stop();
    setIsSpeakingId(id);
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const ctx = audioContextRef.current;
      const base64Audio = await GeminiService.generateSpeech(cleanText);
      const audioBuffer = await GeminiService.decodeAudioData(GeminiService.decodeBase64(base64Audio), ctx);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setIsSpeakingId(null);
      activeSourceRef.current = source;
      source.start();
    } catch (e) {
      console.error("Vocal synthesis failed:", e);
      setIsSpeakingId(null);
    }
  }, [isSpeakingId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !attachment) || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      attachment: attachment ? { type: attachment.mimeType.startsWith('video') ? 'video' : 'image', url: attachment.url, mimeType: attachment.mimeType } : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    const currentAttachment = attachment;
    setInput('');
    setAttachment(null);
    setIsLoading(true);

    try {
      const history = messages.slice(-10).map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));
      
      const assistantId = (Date.now() + 1).toString();
      let streamedText = '';
      let groundingLinks: any[] = [];

      setMessages(prev => [...prev, {
        id: assistantId,
        role: 'assistant',
        content: '',
        timestamp: Date.now()
      }]);

      const stream = GeminiService.chatStream(currentInput, history, {
        useSearch,
        useTurbo,
        useThinking,
        attachment: currentAttachment ? { data: currentAttachment.data, mimeType: currentAttachment.mimeType } : undefined
      });

      for await (const chunk of stream) {
        const textPart = chunk.text || '';
        streamedText += textPart;
        
        if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
           groundingLinks = chunk.candidates[0].groundingMetadata.groundingChunks.map((c: any) => {
             if (c.web) return { title: c.web.title, uri: c.web.uri };
             return null;
           }).filter(Boolean);
        }

        setMessages(prev => prev.map(m => 
          m.id === assistantId ? { ...m, content: streamedText, groundingLinks } : m
        ));
      }
      
      if (autoSpeak) {
        handleSpeech(streamedText, assistantId);
      }
    } catch (error: any) {
      console.error("Chat Execution Error:", error);
      const msg = error?.message || String(error);
      const is404 = msg.toLowerCase().includes('not found') || msg.toLowerCase().includes('404');
      const isKeyError = GeminiService.isKeyError(error);
      
      let errorMsg = "Neural sync interruption. The global knowledge grid is experiencing high latency. Please retry transmission.";
      
      if (is404) {
        errorMsg = "RESOURCE NOT FOUND (404): The requested neural model is unavailable for this project link. Ensure you are using a billing-enabled API key with access to Gemini 2.5/3 experimental cores.";
      } else if (isKeyError) {
        errorMsg = "CRITICAL AUTH ERROR: Neural Key invalid or restricted. Vision and search protocols require a paid/billing-enabled project. Please verify your API Key in settings.";
      }
      
      setMessages(prev => {
        const filtered = prev.filter(m => m.content !== '' || m.role !== 'assistant');
        return [...filtered, { 
          id: 'error-' + Date.now(), 
          role: 'assistant', 
          content: errorMsg, 
          timestamp: Date.now() 
        }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto px-4 lg:px-8 py-6 relative">
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pb-48 scroll-smooth pr-2">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
            <div className={`max-w-[85%] lg:max-w-[75%] rounded-2xl p-4 lg:p-6 relative group ${msg.role === 'user' ? 'bg-green-500 text-black font-semibold shadow-[0_0_20px_#22c55e44]' : msg.id.startsWith('error') ? 'bg-red-500/10 border border-red-500/30 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.2)]' : 'glass-card border-green-500/20 text-gray-200 shadow-xl'}`}>
              {msg.attachment && (
                <div className="mb-4 rounded-xl overflow-hidden border border-green-500/20 shadow-lg">
                  {msg.attachment.type === 'image' ? (
                    <img src={msg.attachment.url} className="w-full max-h-72 object-cover hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <video src={msg.attachment.url} className="w-full max-h-72 object-cover" controls />
                  )}
                </div>
              )}
              <div className="text-sm lg:text-base whitespace-pre-wrap leading-relaxed mb-2 prose prose-invert max-w-none prose-green">
                {msg.content || (msg.role === 'assistant' && !isLoading ? '' : '...')}
              </div>
              
              {msg.role === 'assistant' && msg.content && !msg.id.startsWith('error') && (
                <div className="absolute -right-12 top-2 flex flex-col gap-2">
                  <button 
                    onClick={() => handleSpeech(msg.content, msg.id)} 
                    className={`p-3 rounded-full hover:bg-green-500/10 transition-all ${isSpeakingId === msg.id ? 'text-green-400 scale-125' : 'text-green-500/30'}`}
                    title="Speak Answer"
                  >
                    <i className={`fa-solid ${isSpeakingId === msg.id ? 'fa-volume-high animate-pulse' : 'fa-volume-low'} text-lg`}></i>
                  </button>
                </div>
              )}

              {msg.id.startsWith('error') && msg.content.includes('404') && (
                <div className="mt-4">
                  <button 
                    onClick={() => GeminiService.openKeySelector()}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-lg"
                  >
                    Switch Project Key
                  </button>
                </div>
              )}
              
              {msg.groundingLinks && msg.groundingLinks.length > 0 && (
                <div className="mt-4 pt-4 border-t border-green-500/10">
                  <span className="text-[10px] uppercase font-bold text-green-500/60 mb-2 block tracking-widest font-orbitron">Knowledge Base</span>
                  <div className="flex flex-wrap gap-2">
                    {msg.groundingLinks.map((link, idx) => (
                      <a key={idx} href={link.uri} target="_blank" rel="noopener noreferrer" className="text-[10px] bg-green-500/5 hover:bg-green-500/20 text-green-400 px-3 py-1 rounded-lg border border-green-500/20 transition-all hover:scale-105">
                        <i className="fa-solid fa-link mr-1"></i> {link.title}
                      </a>
                    ))}
                  </div>
                </div>
              )}
              <div className="text-[8px] opacity-30 mt-2 uppercase font-orbitron tracking-tighter">
                {new Date(msg.timestamp).toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        {isLoading && !messages[messages.length-1]?.content && (
          <div className="flex justify-start">
            <div className="glass-card border-green-500/20 p-4 rounded-xl flex items-center gap-4">
              <div className="relative w-6 h-6">
                <div className="absolute inset-0 border-2 border-green-500/20 rounded-full"></div>
                <div className="absolute inset-0 border-2 border-t-green-500 rounded-full animate-spin"></div>
              </div>
              <span className="text-[10px] font-orbitron text-green-500 animate-pulse uppercase tracking-[0.2em]">Bursting Data...</span>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-6 left-0 right-0 px-4 max-w-5xl mx-auto z-10">
        <div className="flex flex-wrap gap-2 mb-4 bg-black/40 p-2 rounded-2xl backdrop-blur-md border border-green-500/10">
          <button onClick={() => setUseTurbo(!useTurbo)} className={`px-4 py-2 rounded-xl text-[10px] font-orbitron font-bold transition-all border ${useTurbo ? 'bg-green-500 text-black border-green-500 shadow-[0_0_15px_#22c55e]' : 'bg-black/40 text-green-500/60 border-green-500/20 hover:bg-green-500/10'}`}>
            <i className="fa-solid fa-bolt mr-2"></i> TURBO
          </button>
          <button onClick={() => setAutoSpeak(!autoSpeak)} className={`px-4 py-2 rounded-xl text-[10px] font-orbitron font-bold transition-all border ${autoSpeak ? 'bg-green-500 text-black border-green-500 shadow-[0_0_15px_#22c55e]' : 'bg-black/40 text-green-500/60 border-green-500/20 hover:bg-green-500/10'}`}>
            <i className={`fa-solid ${autoSpeak ? 'fa-microphone' : 'fa-microphone-slash'} mr-2`}></i> AUTO-SPEAK
          </button>
          <button onClick={() => setUseSearch(!useSearch)} className={`px-4 py-2 rounded-xl text-[10px] font-orbitron font-bold transition-all border ${useSearch ? 'bg-green-500 text-black border-green-500 shadow-[0_0_15px_#22c55e]' : 'bg-black/40 text-green-500/60 border-green-500/20 hover:bg-green-500/10'}`}>
            <i className="fa-solid fa-earth-americas mr-2"></i> WORLD DATA
          </button>
        </div>

        <form onSubmit={handleSubmit} className="relative group">
          <input ref={fileInputRef} type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
          
          {attachment && (
            <div className="absolute -top-24 left-0 p-2 glass-card rounded-xl border-green-500/40 animate-in slide-in-from-bottom-4">
              <div className="relative group">
                <img src={attachment.url} className="w-16 h-16 object-cover rounded-lg border border-green-500/20" />
                <button type="button" onClick={() => setAttachment(null)} className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-[10px] border border-black shadow-lg">
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>
            </div>
          )}

          <div className="absolute left-3 top-1/2 -translate-y-1/2">
            <button type="button" onClick={() => fileInputRef.current?.click()} className="w-10 h-10 rounded-xl hover:bg-green-500/10 text-green-500/40 hover:text-green-500 transition-all flex items-center justify-center">
              <i className="fa-solid fa-plus text-lg"></i>
            </button>
          </div>
          
          <input 
            value={input} 
            onChange={(e) => setInput(e.target.value)} 
            placeholder={useTurbo ? "Fast query mode active..." : "Ask anything about the world..."} 
            className="w-full bg-black/60 border border-green-500/30 rounded-2xl py-5 pl-14 pr-32 focus:outline-none focus:border-green-500 transition-all glass-card placeholder:text-gray-700 text-lg shadow-2xl" 
          />
          
          <button 
            type="submit" 
            disabled={(!input.trim() && !attachment) || isLoading} 
            className="absolute right-3 top-2.5 bottom-2.5 px-8 rounded-xl neon-bg text-black font-black uppercase text-xs tracking-widest hover:brightness-110 active:scale-95 transition-all shadow-[0_0_20px_#22c55e]"
          >
            EXECUTE
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
