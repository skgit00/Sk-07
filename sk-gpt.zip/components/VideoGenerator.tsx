
import React, { useState, useRef, useEffect } from 'react';
import { GeminiService } from '../services/geminiService';
import { VideoAspectRatio } from '../types';

const VideoGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [ratio, setRatio] = useState<VideoAspectRatio>('16:9');
  const [isKeyValid, setIsKeyValid] = useState<boolean>(true);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkKey = async () => {
      const hasKey = await GeminiService.checkKeySelection();
      setIsKeyValid(hasKey);
    };
    checkKey();
  }, []);

  const handleOpenKeySelection = async () => {
    await GeminiService.openKeySelector();
    setIsKeyValid(true);
    setErrorMessage(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim() && !selectedImage) return;
    setIsGenerating(true);
    setVideoUrl(null);
    setErrorMessage(null);
    setStatus('Initializing Imagination Hub...');
    
    try {
      let operation = await GeminiService.startVideoGeneration(prompt, { ratio, imageBase64: selectedImage || undefined });
      while (!operation.done) {
        setStatus('Synthesizing motion... (2-5 mins)');
        await new Promise(r => setTimeout(r, 10000));
        operation = await GeminiService.pollVideoOperation(operation);
      }
      if (operation.response?.generatedVideos?.[0]?.video?.uri) {
        setStatus('Decrypting neural output...');
        const blob = await GeminiService.fetchVideoBlob(operation.response.generatedVideos[0].video.uri);
        setVideoUrl(URL.createObjectURL(blob));
        setStatus('Synthesis Complete.');
      } else { 
        throw new Error('Neural link dropped during synthesis.'); 
      }
    } catch (e: any) {
      console.error("Motion Core Failure:", e);
      if (GeminiService.isKeyError(e)) {
        setIsKeyValid(false);
        setErrorMessage("NEURAL KEY RESTRICTED: Motion cores require billing-enabled projects.");
      } else {
        setErrorMessage(e.message || "MOTION SYNC ERROR: Imagination hub unavailable.");
      }
    } finally {
      setIsGenerating(false);
      setStatus('');
    }
  };

  if (!isKeyValid) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <div className="glass-card p-12 rounded-[2.5rem] border-red-500/30 text-center flex flex-col items-center max-w-2xl animate-in fade-in zoom-in shadow-[0_0_50px_rgba(239,68,68,0.1)]">
          <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 text-3xl mb-8 border border-red-500/20 shadow-[0_0_30px_rgba(239,68,68,0.2)] animate-pulse">
            <i className="fa-solid fa-video-slash"></i>
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-red-500 mb-4 tracking-tight uppercase">Motion Link Terminated</h3>
          <p className="text-gray-400 mb-8 leading-relaxed">
            Veo video synthesis is an advanced compute protocol. It requires a <span className="text-red-500 font-bold">Paid API Key</span> and active billing to access temporal rendering layers.
          </p>
          <div className="flex flex-col gap-4 w-full">
            <button 
              onClick={handleOpenKeySelection}
              className="w-full py-5 bg-red-500 text-white font-black rounded-2xl hover:scale-105 transition-all shadow-[0_0_40px_rgba(239,68,68,0.3)] active:scale-95 text-xs uppercase tracking-widest"
            >
              Re-Authorize Motion Key
            </button>
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-green-400 text-[10px] font-bold uppercase tracking-widest transition-colors"
            >
              Billing Protocol Access <i className="fa-solid fa-up-right-from-square ml-1 text-[8px]"></i>
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto flex flex-col h-full relative z-10">
      <div className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-orbitron font-black text-green-400 mb-2 tracking-tighter uppercase">Motion Protocol</h2>
          <p className="text-green-500/60 text-[10px] uppercase font-bold tracking-widest flex items-center gap-2"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> Veo Cinematic Architecture</p>
        </div>
        <button 
          onClick={handleOpenKeySelection}
          className="text-[10px] font-orbitron font-bold text-green-500/60 hover:text-green-400 transition-colors flex items-center gap-2"
        >
          <i className="fa-solid fa-key"></i> UPDATE KEY
        </button>
      </div>

      <div className="glass-card p-8 rounded-[2.5rem] border-green-500/20 shadow-2xl relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-1">
              <label className="text-[10px] font-orbitron font-bold text-green-500/80 uppercase tracking-widest">Temporal Directive</label>
              <div className="flex gap-2">
                {['16:9', '9:16'].map(r => (
                  <button key={r} onClick={() => setRatio(r as VideoAspectRatio)} className={`px-3 py-1 rounded-lg text-[10px] font-bold border ${ratio === r ? 'bg-green-500 text-black border-green-500 shadow-[0_0_10px_#22c55e44]' : 'bg-black/40 text-green-500 border-green-500/20'}`}>{r}</button>
                ))}
              </div>
            </div>
            <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Describe the temporal evolution..." className="w-full bg-black/40 border border-green-500/20 rounded-[1.5rem] p-6 min-h-[160px] focus:outline-none focus:border-green-500 transition-all text-lg resize-none shadow-inner" />
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-orbitron font-bold text-green-500/80 uppercase tracking-widest">Neural Seed (Static to Motion)</label>
            <div onClick={() => !isGenerating && fileInputRef.current?.click()} className={`w-full aspect-video rounded-[1.5rem] border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative ${selectedImage ? 'border-green-500/50 bg-black/60 shadow-xl' : 'border-green-500/10 hover:border-green-500/30 bg-black/20'}`}>
              {selectedImage ? (
                <>
                  <img src={selectedImage} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <p className="text-white text-[10px] font-bold uppercase tracking-widest">Replace Seed</p>
                  </div>
                </>
              ) : (
                <div className="text-center opacity-40"><i className="fa-solid fa-burst text-3xl mb-3"></i><p className="text-[10px] font-bold uppercase tracking-widest">Initialize Frame 0</p></div>
              )}
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 text-[11px] font-bold uppercase tracking-widest text-center shadow-[0_0_15px_rgba(239,68,68,0.1)]">
            <i className="fa-solid fa-bug mr-2"></i> {errorMessage}
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-6 items-center justify-between border-t border-green-500/10 pt-8">
          <div className="text-[10px] font-orbitron text-green-500/60 tracking-widest font-black uppercase">Core Protocol: VEO 3.1 FAST SYNC</div>
          <button 
            onClick={handleGenerate} 
            disabled={(!prompt.trim() && !selectedImage) || isGenerating} 
            className="w-full md:w-auto px-16 py-5 neon-bg text-black font-black rounded-2xl flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-20 shadow-[0_0_30px_#22c55e44]"
          >
            {isGenerating ? <><i className="fa-solid fa-dna fa-spin"></i> SYNCING TEMPORAL DATA...</> : <><i className="fa-solid fa-play"></i> EXECUTE MOTION</>}
          </button>
        </div>

        {status && <div className="mt-6 p-4 rounded-xl bg-green-500/5 text-[10px] font-orbitron text-green-500 border border-green-500/10 animate-pulse text-center tracking-widest uppercase">{status}</div>}
      </div>

      {videoUrl && (
        <div className="mt-8 glass-card p-6 rounded-[2rem] border-green-500/30 animate-in fade-in slide-in-from-bottom-8 shadow-2xl">
          <video src={videoUrl} controls autoPlay loop className="w-full rounded-[1.5rem] shadow-2xl border border-green-500/20" />
          <div className="mt-6 flex justify-between items-center px-4">
            <span className="text-[9px] font-orbitron text-green-500 uppercase tracking-widest font-black flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Render Success
            </span>
            <a href={videoUrl} download="SK-GPT-MOTION-SYNC.mp4" className="px-8 py-3 bg-white/5 hover:bg-green-500 hover:text-black rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg">Export Data</a>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoGenerator;
