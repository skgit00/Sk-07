
import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import ChatInterface from './components/ChatInterface';
import ImageGenerator from './components/ImageGenerator';
import VideoGenerator from './components/VideoGenerator';
import LiveInterface from './components/LiveInterface';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.CHAT);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Responsive sidebar handling
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="flex h-screen w-full bg-transparent overflow-hidden text-gray-200">
      {/* Sidebar Navigation */}
      <Sidebar 
        activeView={activeView} 
        onViewChange={setActiveView} 
        isOpen={isSidebarOpen}
        toggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden bg-black/20">
        {/* Mobile Header */}
        <header className="lg:hidden flex items-center justify-between p-4 border-b border-green-500/20 glass-card">
          <button onClick={() => setIsSidebarOpen(true)} className="text-green-400">
            <i className="fa-solid fa-bars text-xl"></i>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full neon-bg flex items-center justify-center text-black font-bold">SK</div>
            <h1 className="font-orbitron font-bold text-green-400">SK GPT</h1>
          </div>
          <div className="w-8"></div>
        </header>

        {/* View Rendering */}
        <div className="flex-1 overflow-auto">
          {activeView === AppView.CHAT && <ChatInterface />}
          {activeView === AppView.LIVE && <LiveInterface />}
          {activeView === AppView.IMAGE && <ImageGenerator />}
          {activeView === AppView.VIDEO && <VideoGenerator />}
        </div>
      </main>
    </div>
  );
};

export default App;
